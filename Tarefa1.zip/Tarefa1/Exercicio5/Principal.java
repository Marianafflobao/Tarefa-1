import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		Scanner pgta = new Scanner(System.in);

		System.out.print("Qual o valor do raio do circulo?");

		double raio = pgta.nextDouble();
		
		double area = (3.14*(Math.pow(raio, 2)));
		
		System.out.print("A area é: "+area);

	}

}
