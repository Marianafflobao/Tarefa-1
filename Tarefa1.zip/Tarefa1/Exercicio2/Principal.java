package Exercicio2;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		int a=1;
		int b=2;
		int c=3;
		int d;
		
		d=a; 
		a=b;
		b=c;
		c=d;
		
		
		
		System.out.println("A:"+a+ "\nB:"+b+"\nC:"+c);
		
	}

}
