package Exercicio1;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		 
		
		 Scanner n1 = new Scanner (System.in);
		 System.out.println("Digite o primeiro número: ");
		 String numero1 = n1.next();
		 String reverso1 = "";
		 for(int i = (numero1.length() - 1); i >= 0; i--){
	            reverso1 += numero1.charAt(i);
	        }
		 
		 Scanner n2 = new Scanner (System.in);
		 System.out.println("Digite o segundo número: ");
		 String numero2 = n1.next();
		 String reverso2 = "";
		 for(int i = (numero2.length() - 1); i >= 0; i--){
	            reverso2 += numero2.charAt(i);
	        }
		 
		 Scanner n3 = new Scanner (System.in);
		 System.out.println("Digite o terceiro número: ");
		 String numero3 = n1.next();
		 
		 String reverso3 = "";
		 for(int i = (numero3.length() - 1); i >= 0; i--){
	            reverso3 += numero3.charAt(i);
	        }
		 
		 System.out.println("Ordem inversa => Primeiro numero: "+ reverso1+"\nSegundo numero: "+ reverso2 + "\nTerceiro numero: "+ reverso3);
		

	}
}