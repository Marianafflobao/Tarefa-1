import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		Scanner pgta1 = new Scanner(System.in);
		System.out.println("Qual a largura da parede?");
		double largura = pgta1.nextDouble();

		Scanner pgta2 = new Scanner(System.in);
		System.out.println("Qual a altura da parede?");
		double altura = pgta2.nextDouble();

		double area = (largura * altura);

		double tintas = (area * 300);

		int qntd = (int) (tintas / 2000);

		if ((tintas/2000) < 1) {
			qntd = 1;
		}
		if (tintas % 2000 != 0) {
			qntd = qntd + 1;
		}
		
		System.out.println("A quantidade de latas que você precisará é: " + qntd);

	}

}