import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner pgta = new Scanner(System.in);
		
		System.out.print("Olá eu sou o Nº 1, como é seu nome?");
		
		String nome = pgta.nextLine();
		
		Scanner pgta2 = new Scanner(System.in);
		
		System.out.print("Qual a sua idade?");
		int idade = pgta2.nextInt();
		
		int diasdevida = idade*365;
		
		System.out.print(nome+" possui "+diasdevida+" dias de vida");
		
	}

}
